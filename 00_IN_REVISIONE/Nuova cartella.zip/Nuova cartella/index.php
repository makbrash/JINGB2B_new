<?php
// index.php

// session_start(); // se serve
// require_once '../config/db.php'; // se serve

// Include header (HTML <head>, se hai un file header separato)
include_once __DIR__ . '/includes/header.php';
?>
<!DOCTYPE html>
<html lang="it">
<head>
  <meta charset="UTF-8" />
  <title>JINGB2B Catalog</title>
  <!-- Manifest per la PWA -->
  <link rel="manifest" href="/manifest.json" />
  <meta name="theme-color" content="#ca674e" />
  <!-- (Facoltativo) Tag che indica "Add to Home Screen" su iOS -->
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
  <!-- Icona, se vuoi apparire su home iOS -->
  <!-- <link rel="apple-touch-icon" href="/assets/img/icon-192.png" /> -->

  <!-- Caricamento CSS -->
  <!-- Se preferisci, import style.css -->
  <link rel="stylesheet" href="/assets/css/style.css" />

  <!-- jQuery: da CDN o local -->
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

  <!-- Registrazione Service Worker -->
  <script>
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('/service-worker.js')
        .then(reg => console.log("Service Worker registrato:", reg.scope))
        .catch(err => console.log("SW registration failed:", err));
    });
  }
  </script>
</head>
<body>

  <header>
    <h1>Catalogo JINGB2B</h1>
    <!-- Eventuali menu, filtri, ecc. -->
  </header>

  <!-- Contenitore catalogo -->
  <div class="catalog-container" id="catalogContainer"></div>

  <!-- Barra di avanzamento per il download massivo -->
  <div id="progressBarContainer" style="display:none;">
    <div id="progressBarWRAP">
      <div id="progressBar_BG"></div>
      <div id="progressBar"></div>
    </div>
  </div>

  <!-- Template nascosto per le card (tuo codice) -->
  <div id="productTemplate" style="display:none;">
    <div class="product-card" data-ean="" data-prev="0">
      <!-- ... immagine, .info, .flexPrice ... -->
    </div>
  </div>

  <footer>
    <p>Copyright ©2025</p>
    <!-- (Eventuali pulsanti, info, ecc.) -->
  </footer>

  <!-- Importa qui i tuoi script: main.js, ecc. -->
  <!-- 1) IndexedDB + logica offline/online -->
  <script src="/assets/js/main.js"></script>

  <!-- 2) Codice relativo alla logica di renderCatalog, lazyLoad? 
       (Puoi averlo già dentro main.js, oppure un file a parte. Esempio: render.js) 
  -->

</body>
</html>
<?php
// include_once __DIR__ . '/includes/footer.php';
?>



<!-- jQuery (assumo che lo importi da qualche CDN o local) -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
// Funzione di debugging per verificare il contenuto della cache
function inspectCache() {
  if ('caches' in window) {
    caches.open('jingb2b-static-v6').then(function(cache) {
      cache.keys().then(function(cachedRequests) {
        console.log('Contenuto della cache:');
        cachedRequests.forEach(function(request) {
          console.log(request.url);
        });
      });
    });
  }
}

// Chiamalo dopo il caricamento della pagina
$(document).ready(function() {
  // Dopo initDB e altre inizializzazioni
  setTimeout(inspectCache, 2000);
});

// *** NUOVO ***
// Se lo desideri: checkAndUpdateCatalog() e downloadAllProducts()
// Queste funzioni servono a fare un “aggiornamento massivo”
// da un endpoint tipo /api/getProducts.php
// Puoi commentarle se preferisci non usarle ora.

</script>
